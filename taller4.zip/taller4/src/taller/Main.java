package taller;


import algorithm.race.AlgorithmCLI;
  
public class Main{
  
  
  public static void main(String[] args){
    
      new AlgorithmCLI().mainMenu();
    
  }
  
}