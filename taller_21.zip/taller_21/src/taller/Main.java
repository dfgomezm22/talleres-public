package taller;

import uniandes.cupi2.tienda.interfaz.*;

public class Main{
  
  public static void main(String[] args){
    
        // Crea la ventana de la interfaz
        InterfazTienda ventana = new InterfazTienda( );
        ventana.setVisible( true );
    
  }
  
}