package taller.test;

import junit.framework.TestCase;

public class MainTest extends TestCase{
   
  public void testSample() {
    assertEquals(2, 2);
  }
  
}